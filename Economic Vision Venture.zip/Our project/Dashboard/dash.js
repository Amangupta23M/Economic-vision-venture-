document.addEventListener('DOMContentLoaded', () => {
    // Initialize Charts
    const ctxInvestment = document.getElementById('investmentChart').getContext('2d');
    const ctxGrowth = document.getElementById('growthChart').getContext('2d');

    const investmentChart = new Chart(ctxInvestment, {
        type: 'bar',
        data: {
            labels: ['Q1', 'Q2', 'Q3', 'Q4'],
            datasets: [{
                label: 'Investments ($)',
                data: [2000000, 3000000, 2500000, 3500000],
                backgroundColor: 'rgba(0, 123, 255, 0.5)',
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    const growthChart = new Chart(ctxGrowth, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Growth Rate (%)',
                data: [2.5, 3.0, 2.8, 3.2, 3.5, 3.7, 4.0, 4.2, 4.3, 4.1, 3.8, 4.0],
                borderColor: 'rgba(0, 123, 255, 1)',
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                fill: true,
                tension: 0.1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Accordion Functionality
    const accordionButtons = document.querySelectorAll('.accordion-button');

    accordionButtons.forEach(button => {
        button.addEventListener('click', () => {
            const content = button.nextElementSibling;

            if (content.style.display === 'block') {
                content.style.display = 'none';
                button.textContent = 'Show Report';
            } else {
                content.style.display = 'block';
                button.textContent = 'Hide Report';
            }
        });
    });
});
