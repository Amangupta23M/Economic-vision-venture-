document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('feedbackForm');
    const responseMessage = document.getElementById('responseMessage');

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const name = form.name.value;
        const email = form.email.value;
        const message = form.message.value;

        // Simulate form submission and response
        setTimeout(() => {
            responseMessage.textContent = 'Thank you for your Message, ' + name + '! We appreciate your input and will get back to you if necessary.';
            form.reset(); // Reset form fields after submission
        }, 500); // Simulate a delay for the response
    });
});
