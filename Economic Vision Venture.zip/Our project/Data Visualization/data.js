document.addEventListener('DOMContentLoaded', () => {
    // Initialize Charts
    const ctxGDPGrowth = document.getElementById('gdpGrowthChart').getContext('2d');
    const ctxMonthlyRevenue = document.getElementById('monthlyRevenueChart').getContext('2d');
    const ctxSectoralInvestment = document.getElementById('sectoralInvestmentChart').getContext('2d');

    // Annual GDP Growth Chart
    const gdpGrowthChart = new Chart(ctxGDPGrowth, {
        type: 'line',
        data: {
            labels: ['2019', '2020', '2021', '2022', '2023'],
            datasets: [{
                label: 'GDP Growth Rate (%)',
                data: [2.5, 3.0, 3.2, 3.5, 3.8],
                borderColor: 'rgba(0, 123, 255, 1)',
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                fill: true,
                tension: 0.1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Monthly Revenue Chart
    const monthlyRevenueChart = new Chart(ctxMonthlyRevenue, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue ($ Million)',
                data: [120, 130, 140, 150, 160, 170, 180, 190, 200, 210, 220, 230],
                backgroundColor: 'rgba(75, 192, 192, 0.5)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Sectoral Investment Distribution Chart
    const sectoralInvestmentChart = new Chart(ctxSectoralInvestment, {
        type: 'pie',
        data: {
            labels: ['Technology', 'Healthcare', 'Education', 'Infrastructure'],
            datasets: [{
                label: 'Investment Distribution (%)',
                data: [40, 25, 15, 20],
                backgroundColor: ['rgba(255, 159, 64, 0.5)', 'rgba(54, 162, 235, 0.5)', 'rgba(75, 192, 192, 0.5)', 'rgba(153, 102, 255, 0.5)'],
                borderColor: ['rgba(255, 159, 64, 1)', 'rgba(54, 162, 235, 1)', 'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true
        }
    });
});
