document.addEventListener('DOMContentLoaded', () => {
    const accordionButtons = document.querySelectorAll('.accordion-button');

    accordionButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Close any open accordion content
            document.querySelectorAll('.accordion-content').forEach(content => {
                if (content !== button.nextElementSibling) {
                    content.style.display = 'none';
                }
            });

            // Toggle the clicked button's content
            const content = button.nextElementSibling;
            if (content.style.display === 'block') {
                content.style.display = 'none';
            } else {
                content.style.display = 'block';
            }
        });
    });
});
