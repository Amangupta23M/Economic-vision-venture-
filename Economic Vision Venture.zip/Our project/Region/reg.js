document.addEventListener('DOMContentLoaded', () => {
    // Initialize Charts
    const ctxRegionalGDP = document.getElementById('regionalGDPChart').getContext('2d');
    const ctxRegionalUnemployment = document.getElementById('regionalUnemploymentChart').getContext('2d');
    const ctxRegionalInvestment = document.getElementById('regionalInvestmentChart').getContext('2d');

    // Regional GDP Comparison Chart
    const regionalGDPChart = new Chart(ctxRegionalGDP, {
        type: 'bar',
        data: {
            labels: ['North', 'South', 'East', 'West'],
            datasets: [{
                label: 'GDP ($ Billion)',
                data: [150, 120, 180, 160],
                backgroundColor: 'rgba(0, 123, 255, 0.5)',
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Regional Unemployment Rate Chart
    const regionalUnemploymentChart = new Chart(ctxRegionalUnemployment, {
        type: 'doughnut',
        data: {
            labels: ['North', 'South', 'East', 'West'],
            datasets: [{
                label: 'Unemployment Rate (%)',
                data: [5.5, 6.0, 4.5, 5.0],
                backgroundColor: ['rgba(255, 99, 132, 0.5)', 'rgba(54, 162, 235, 0.5)', 'rgba(75, 192, 192, 0.5)', 'rgba(153, 102, 255, 0.5)'],
                borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true
        }
    });

    // Regional Investment Distribution Chart
    const regionalInvestmentChart = new Chart(ctxRegionalInvestment, {
        type: 'pie',
        data: {
            labels: ['North', 'South', 'East', 'West'],
            datasets: [{
                label: 'Investment Distribution (%)',
                data: [30, 25, 20, 25],
                backgroundColor: ['rgba(255, 159, 64, 0.5)', 'rgba(255, 205, 86, 0.5)', 'rgba(75, 192, 192, 0.5)', 'rgba(153, 102, 255, 0.5)'],
                borderColor: ['rgba(255, 159, 64, 1)', 'rgba(255, 205, 86, 1)', 'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true
        }
    });
});
